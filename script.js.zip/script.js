let button = document.querySelector("button"); 
button.onclick = function () { 
    let name = prompt("Enter your name:"); 
    if (name != null) { 
        document.querySelector("h1").innerHTML = "Welcome " + name + '!'; 
    } 
} 
let imgjs = document.querySelector('img'); 
imgjs.onclick = () => { 
    if (document.querySelector('img').getAttribute('src') === 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpgN_NSLlZoLJ4MxTvCw8ybMBDl2zUUfcNlHQ4L8UrS7iWNLz9BA4R9N10d_sBvw32NOI&usqp=CAU') { 
        document.querySelector('img').setAttribute('src', 'https://ecsmedia.pl/c/tokyo-ghoul-kaneki-plakat-61x91-5-cm-b-iext65832908.jpg' ); 
    } else { 
        document.querySelector('img').setAttribute('src', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpgN_NSLlZoLJ4MxTvCw8ybMBDl2zUUfcNlHQ4L8UrS7iWNLz9BA4R9N10d_sBvw32NOI&usqp=CAU'); 
    } 
}